export interface Person {
  id: string;
  name: string;
}
